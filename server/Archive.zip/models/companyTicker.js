const { Schema, default: mongoose } = require("mongoose");

const tickerSchema = new Schema({
    script: { type: String, required: true }, 
    ltp: { type: Number, required: true },
    pointChange: { type: Number, default: 0 },
    percentageChange: { type: Number, default: 0 },
    open: { type: Number },
    high: { type: Number },
    low: { type: Number },
    volume: { type: Number }, // Total quantity traded
    turnover: { type: Number }, // Total value traded (LTP * Qty)
    prevClose: { type: Number },
    lastUpdated: { type: Date, default: Date.now }
  });
  
  const Ticker = mongoose.model('Ticker', tickerSchema);
  module.exports = Ticker;