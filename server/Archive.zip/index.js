const express = require('express')
const app = express()
const port = 8080
app.use(express.json())

const mongoose = require('mongoose');
const Ticker = require('./models/companyTicker');

// Replace with your connection string
const mongoURI = 'mongodb://localhost:27017/aidb';

mongoose.connect(mongoURI)
  .then(() => console.log('Connected to MongoDB!'))
  .catch(err => console.error('Connection error:', err));

  const { Schema } = mongoose;

  const userSchema = new Schema({
    name: String, // String is shorthand for {type: String}
    password: String,
    phoneNumber: String,
    isVip: Boolean
  });
  
  const User = mongoose.model('User', userSchema);


app.post('/users', async (req, res) => {
  await User.create(req.body)
  res.send('users created')
})


app.get('/users', async (req, res) => {
  const data = await User.find()
  res.send(data)
})



app.put('/users/:id', async (req, res) => {
  const data = await User.findByIdAndUpdate(req.params.id, req.body)
  res.send('userd updated')
})



app.delete('/users/:id', async (req, res) => {
  const data = await User.findByIdAndDelete(req.params.id)
  res.send('userd deleted')
})

///


app.post('/ticker', async (req, res) => {
  await Ticker.create(req.body)
  res.send('users created')
})


app.get('/ticker', async (req, res) => {
  const data = await Ticker.find()
  res.send(data)
})



app.put('/ticker/:id', async (req, res) => {
  const data = await Ticker.findByIdAndUpdate(req.params.id, req.body)
  res.send('userd updated')
})



app.delete('/ticker/:id', async (req, res) => {
  const data = await Ticker.findByIdAndDelete(req.params.id)
  res.send('userd deleted')
})

///

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
